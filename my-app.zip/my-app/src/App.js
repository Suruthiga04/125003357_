import logo from "./logo.svg";
import "./App.css";
import React from "react";
import ProductList from "./product";

function App() {
  return (
    <div className="App">
      <p>Punt Partners</p>
    </div>
  );
}

export default App;
